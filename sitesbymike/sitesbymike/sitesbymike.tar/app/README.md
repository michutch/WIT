Welcome to the Gomix Template 1
==============================

A starter project for learning Gomix
